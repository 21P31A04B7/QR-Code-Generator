# HTML CSS JAVASCRIPT 10 PRACTICE PROJECTS - QR Code Generator 

## Projects that we are going to build in this complete practice course

- Project 1 Life Timer App
- Project 2 Github Search Profile App
- Project 3 Marks Calculator App
- Project 4 Math Quiz App
- Project 5 Product Filter & Search App
- Project 6 Color Palette Generator App
- Project 7 QR Code Generator App
- Project 8 Expense Tracker App
- Project 9 Password Generator App
- Project 10 Drawer & Dropdown Menu App

Live Link: 

You can download images and icons from here from github repo

If You Learn Some thing - then Please Support this channel
- You Can Support me - For Free , Just By Sending me Tip From Brave Browser. ( BAT Coin )
- [![image](https://raw.githubusercontent.com/anshuopinion/10-Practice-Project-Html-CSS/master/Readme%20File/howtosupport.png)](https://www.youtube.com/c/dosomecoding)

- UPI ALSO AVAILABLE
- ![image](https://user-images.githubusercontent.com/50476777/189511981-336a53d1-d46a-4d75-882f-6e6213e4e379.png)


